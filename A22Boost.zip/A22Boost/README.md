# A22 Boost (Galaxy A22 4G, Helio G80, root)

1. Instale o Android Studio e abra esta pasta (ele baixa o Gradle sozinho).
2. Build > Build APK(s). Instale o APK no celular.
3. Abra o app e conceda root no Magisk.

Perfis limitam a frequência máxima da CPU (60/80/100%).
O controle térmico reduz 10% por vez quando a bateria passa do limite e devolve ao esfriar.
As frequências são lidas do próprio aparelho (nada fixo no código).
Se as frequências não mudarem, o kernel/Samsung pode estar sobrescrevendo scaling_max_freq.
