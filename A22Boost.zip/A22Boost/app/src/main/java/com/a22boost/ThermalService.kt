package com.a22boost

import android.app.*
import android.content.Intent
import android.os.IBinder
import kotlin.concurrent.thread

/** Reduz a frequência da CPU em passos de 10% quando a bateria passa do limite e devolve quando esfria. */
class ThermalService : Service() {
    @Volatile private var running = false
    @Volatile private var limit = 40f

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        limit = intent?.getFloatExtra("limit", 40f) ?: 40f
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("a22", "A22 Boost", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "a22")
            .setContentTitle("Controle térmico ativo")
            .setContentText("Limite: ${limit.toInt()} °C")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        startForeground(1, n)
        if (!running) {
            running = true
            thread { loop() }
        }
        return START_STICKY
    }

    private fun loop() {
        var cap = 100
        while (running) {
            val t = CpuTuner.batteryTempC(this)
            val next = when {
                t >= limit -> (cap - 10).coerceAtLeast(50)
                t <= limit - 3 -> (cap + 10).coerceAtMost(100)
                else -> cap
            }
            if (next != cap) { cap = next; CpuTuner.setCap(cap) }
            Thread.sleep(5000)
        }
    }

    override fun onDestroy() {
        running = false
        thread { CpuTuner.setCap(100) }
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
