package com.a22boost

import android.content.Context
import android.content.Intent
import android.content.IntentFilter

object CpuTuner {
    private const val BASE = "/sys/devices/system/cpu/cpufreq"

    private fun policies(): List<String> =
        RootShell.run("ls $BASE").split(Regex("\\s+")).filter { it.startsWith("policy") }

    private fun read(p: String, file: String) = RootShell.run("cat $BASE/$p/$file")

    /** Limita a frequência máxima de cada cluster a [percent]% do máximo de fábrica. */
    fun setCap(percent: Int) {
        val cmds = policies().mapNotNull { p ->
            val hw = read(p, "cpuinfo_max_freq").toLongOrNull() ?: return@mapNotNull null
            val target = hw * percent / 100
            val freqs = read(p, "scaling_available_frequencies")
                .split(" ").mapNotNull { it.trim().toLongOrNull() }.sorted()
            val f = if (freqs.isEmpty()) target else (freqs.lastOrNull { it <= target } ?: freqs.first())
            "chmod 644 $BASE/$p/scaling_max_freq; echo $f > $BASE/$p/scaling_max_freq"
        }
        if (cmds.isNotEmpty()) RootShell.run(cmds.joinToString("; "))
    }

    /** Frequência atual de cada cluster, em MHz. */
    fun currentMhz(): List<Long> =
        policies().mapNotNull { read(it, "scaling_cur_freq").toLongOrNull()?.div(1000) }

    /** Temperatura da bateria em °C (não precisa de root). */
    fun batteryTempC(ctx: Context): Float {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return (i?.getIntExtra("temperature", 0) ?: 0) / 10f
    }
}
