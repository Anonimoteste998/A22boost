package com.a22boost

import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader

/** Mantém UMA sessão de root aberta e reaproveita para todos os comandos (o Magisk só avisa uma vez). */
object RootShell {
    private var proc: Process? = null
    private var out: DataOutputStream? = null
    private var inp: BufferedReader? = null
    private const val END = "__A22_END__"

    @Synchronized
    private fun ensure(): Boolean {
        proc?.let {
            try { it.exitValue(); proc = null } catch (e: IllegalThreadStateException) { return true }
        }
        return try {
            val p = ProcessBuilder("su").redirectErrorStream(true).start()
            proc = p
            out = DataOutputStream(p.outputStream)
            inp = BufferedReader(InputStreamReader(p.inputStream))
            true
        } catch (e: Exception) { false }
    }

    @Synchronized
    fun run(cmd: String): String {
        if (!ensure()) return ""
        return try {
            out!!.writeBytes("$cmd\necho $END\n")
            out!!.flush()
            val sb = StringBuilder()
            while (true) {
                val line = inp!!.readLine() ?: break
                if (line == END) break
                sb.appendLine(line)
            }
            sb.toString().trim()
        } catch (e: Exception) {
            proc?.destroy(); proc = null
            ""
        }
    }

    fun hasRoot(): Boolean = run("id").contains("uid=0")
}
