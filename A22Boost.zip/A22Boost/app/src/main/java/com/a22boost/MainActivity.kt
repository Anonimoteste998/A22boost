package com.a22boost

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var limitLabel: TextView
    private var limit = 40
    private var running = true

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        status = TextView(this).apply { textSize = 18f; text = "Verificando root..." }
        root.addView(status)

        fun btn(label: String, pct: Int) = Button(this).apply {
            text = label
            setOnClickListener { thread { CpuTuner.setCap(pct) }; toast("$label aplicado") }
        }
        root.addView(btn("Economia (60%)", 60))
        root.addView(btn("Equilibrado (80%)", 80))
        root.addView(btn("Desempenho (100%)", 100))

        limitLabel = TextView(this).apply { text = "Limite de temperatura: $limit °C"; setPadding(0, 48, 0, 0) }
        root.addView(limitLabel)
        root.addView(SeekBar(this).apply {
            max = 15; progress = limit - 35
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    limit = 35 + p
                    limitLabel.text = "Limite de temperatura: $limit °C"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        root.addView(Switch(this).apply {
            text = "Controle térmico automático"
            gravity = Gravity.CENTER_VERTICAL
            setOnCheckedChangeListener { _, on ->
                val i = Intent(this@MainActivity, ThermalService::class.java).putExtra("limit", limit.toFloat())
                if (on) startForegroundService(i) else stopService(i)
            }
        })
        setContentView(root)

        thread {
            val ok = RootShell.hasRoot()
            ui.post { if (!ok) status.text = "Sem acesso root. Conceda permissão no Magisk." }
            if (ok) poll()
        }
    }

    private fun poll() {
        while (running) {
            val mhz = CpuTuner.currentMhz()
            val t = CpuTuner.batteryTempC(this)
            ui.post { status.text = "Bateria: $t °C\nCPU (MHz por cluster): ${mhz.joinToString(" / ")}" }
            Thread.sleep(2000)
        }
    }

    private fun toast(s: String) = ui.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    override fun onDestroy() { running = false; super.onDestroy() }
}
