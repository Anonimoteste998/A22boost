package com.a22boost

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())

    private val BG = Color.parseColor("#0F0A1A")
    private val CARD = Color.parseColor("#1C1230")
    private val STROKE = Color.parseColor("#3B2A5E")
    private val PURPLE = Color.parseColor("#8B5CF6")
    private val TEXT = Color.parseColor("#F3EEFF")
    private val MUTED = Color.parseColor("#A99BC9")

    private lateinit var tempView: TextView
    private lateinit var cpuView: TextView
    private lateinit var rootView: TextView
    private lateinit var limitLabel: TextView
    private val profileButtons = mutableListOf<TextView>()
    private var limit = 40
    @Volatile private var polling = false
    private var gen = 0
    private var rootOk = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun card(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = round(CARD, 20, STROKE)
        setPadding(dp(20), dp(18), dp(20), dp(18))
        views.forEach { addView(it) }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(dp(16), dp(14), dp(16), 0) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        window.statusBarColor = Color.parseColor("#4C1D95")
        window.navigationBarColor = BG

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(buildBanner())

        // Estatísticas
        tempView = tv("--", 40f, TEXT, true)
        cpuView = tv("--", 22f, TEXT, true)
        val temp = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addView(tempView); addView(tv("Bateria", 13f, MUTED))
        }
        val cpu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addView(cpuView); addView(tv("CPU (MHz por cluster)", 13f, MUTED))
        }
        rootView = tv("● Verificando root...", 13f, MUTED).apply { setPadding(0, dp(14), 0, 0) }
        col.addView(card(
            LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(temp); addView(cpu) },
            rootView
        ))

        // Perfis
        val names = listOf("Economia", "Equilibrado", "Desempenho")
        val pcts = listOf(60, 80, 100)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        names.forEachIndexed { i, n ->
            val btn = tv(n, 14f, MUTED, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(14), 0, dp(14))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { setMargins(if (i == 0) 0 else dp(8), 0, 0, 0) }
                setOnClickListener {
                    selectProfile(i)
                    thread { CpuTuner.setCap(pcts[i]) }
                    Toast.makeText(this@MainActivity, "$n aplicado", Toast.LENGTH_SHORT).show()
                }
            }
            profileButtons.add(btn)
            row.addView(btn)
        }
        selectProfile(-1)
        col.addView(card(
            tv("Perfil de desempenho", 16f, TEXT, true).apply { setPadding(0, 0, 0, dp(12)) },
            row
        ))

        // Controle térmico
        limitLabel = tv("Limite de temperatura: $limit °C", 14f, MUTED).apply { setPadding(0, dp(12), 0, 0) }
        val seek = SeekBar(this).apply {
            max = 15
            progress = limit - 35
            progressTintList = ColorStateList.valueOf(PURPLE)
            thumbTintList = ColorStateList.valueOf(PURPLE)
            progressBackgroundTintList = ColorStateList.valueOf(STROKE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    limit = 35 + p
                    limitLabel.text = "Limite de temperatura: $limit °C"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val sw = Switch(this).apply {
            text = "Ativar controle automático"
            setTextColor(TEXT)
            textSize = 15f
            thumbTintList = ColorStateList.valueOf(PURPLE)
            trackTintList = ColorStateList.valueOf(Color.parseColor("#55766AA8"))
            setPadding(0, dp(16), 0, 0)
            setOnCheckedChangeListener { _, on ->
                val i = Intent(this@MainActivity, ThermalService::class.java)
                    .putExtra("limit", limit.toFloat())
                if (on) startForegroundService(i) else stopService(i)
            }
        }
        col.addView(card(
            tv("Controle térmico", 16f, TEXT, true),
            tv("Reduz a CPU quando o celular esquenta e devolve quando esfria.", 13f, MUTED)
                .apply { setPadding(0, dp(4), 0, 0) },
            limitLabel, seek, sw
        ))

        col.addView(tv("Feito para Galaxy A22 4G • requer root", 12f, MUTED).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, dp(32))
        })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(col)
        })

        thread {
            val ok = RootShell.hasRoot()
            ui.post {
                rootView.text = if (ok) "● Root ativo" else "● Sem root — conceda permissão no Magisk"
                rootView.setTextColor(Color.parseColor(if (ok) "#34D399" else "#F87171"))
            }
            rootOk = ok
            if (ok) ui.post { startPolling() }
        }
    }

    /** Capa: usa res/drawable/capa.jpg (ou .png) se existir; senão, um degradê roxo. */
    private fun buildBanner(): View {
        val frame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230))
        }
        val capa = resources.getIdentifier("capa", "drawable", packageName)
        if (capa != 0) {
            frame.addView(ImageView(this).apply {
                setImageResource(capa)
                scaleType = ImageView.ScaleType.CENTER_CROP
            })
        } else {
            frame.background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#4C1D95"), Color.parseColor("#7C3AED"), Color.parseColor("#C026D3"))
            )
            frame.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_fg)
                alpha = 0.18f
                layoutParams = FrameLayout.LayoutParams(dp(220), dp(220), Gravity.END or Gravity.TOP)
                    .apply { setMargins(0, dp(10), dp(-20), 0) }
            })
        }
        frame.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.parseColor("#990F0A1A"), BG)
            )
        })
        frame.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), 0, dp(20), dp(20))
            addView(tv("A22 Boost", 30f, Color.WHITE, true))
            addView(tv("Desempenho com temperatura sob controle", 14f, Color.parseColor("#E9DDFF")))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
            )
        })
        return frame
    }

    private fun selectProfile(sel: Int) {
        profileButtons.forEachIndexed { i, b ->
            b.background = if (i == sel) round(PURPLE, 14) else round(BG, 14, STROKE)
            b.setTextColor(if (i == sel) Color.WHITE else MUTED)
        }
    }

    /** Atualiza o painel só enquanto o app está na tela (economiza bateria). */
    private fun startPolling() {
        if (!rootOk || polling) return
        polling = true
        val my = ++gen
        thread {
            while (polling && my == gen) {
                val mhz = CpuTuner.currentMhz()
                val t = CpuTuner.batteryTempC(this)
                ui.post {
                    tempView.text = String.format("%.1f°", t)
                    tempView.setTextColor(
                        Color.parseColor(if (t < 38) "#34D399" else if (t < 42) "#FBBF24" else "#F87171")
                    )
                    cpuView.text = if (mhz.isEmpty()) "--" else mhz.joinToString(" / ")
                }
                Thread.sleep(2000)
            }
        }
    }

    override fun onResume() { super.onResume(); startPolling() }
    override fun onPause() { polling = false; super.onPause() }
}
